#coding: utf-8
import public,re

class databaseBase:

    pass